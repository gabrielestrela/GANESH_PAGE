#!/bin/bash

#########################################
#										#
#		Ganesh WebPage Manager			#
#										#
# 	Download and upload files from		#
# 	ganesh server.						#
#										#
#										#
#	PASSWORD = ")rUhHXS8b2S//X#A"		#
#										#
#########################################

function printHelp
{
	echo ""
	echo "usage: $0 <OPTION> [FILE PATH]"
	echo ""
	echo "OPTIONS:"
	echo "    -h:    This help"
	echo "    -u:    UPLOAD file from GANESH host"
	echo "    -d:    DOWNLOAD file from GANESH host"
	echo "    -c:    Connect to the GANESH host by ssh"
	echo ""
	echo "Examples:"
	echo "$ sh $0 -h"
	echo "$ sh $0 -u index.html"
	echo "$ sh $0 -d site_bkp.zip"
	echo "$ sh $0 -c"
}


OPTION=$1
FILE=$2
USER="ganesh"
HOST="143.107.183.54"
HOST_PATH="$USER@$HOST:$FILE"


# Print help case asked
if [[ $OPTION == "-h" || $OPTION == "" ]]; then printHelp

# Check if host is responding the request
elif [[ ! $(ping -c 1 $HOST | grep "64 bytes") ]]; then
	echo ""
	echo "Unable to connect to target $HOST. Host is unreachable."
	exit

# Flag for direct connection with the server
elif [[ $OPTION == "-c" ]]; then
	echo "Connecting to host $HOST by ssh"
	ssh $USER@$HOST
	echo ""
	echo "Successfully connected to host $HOST"

else
	# Check if file is blank
	if [[ $FILE == "" ]]; then
		echo ""
		echo "No file selected. Please select a file."
		exit

	# Flag for download specified file
	elif [[ $OPTION == "-d" ]]; then
		echo "Downloading file \"$FILE\" from host $HOST_PATH"
		scp $HOST_PATH $FILE
		echo ""
		echo "File \"$FILE\" was successfully downloaded from host $HOST_PATH"

	# Check if specified file exists
	elif [[ $(ls $FILE 2> /dev/null) == $FILE ]]; then
		
		# Flag for download specified file
		#if [[ $OPTION == "-d" ]]; then
		#	echo "Downloading file \"$FILE\" from host $HOST_PATH"
		#	scp $HOST_PATH $FILE
		#	echo ""
		#	echo "File \"$FILE\" was successfully downloaded from host $HOST_PATH"

		# Flag for upload specified file
		if [[ $OPTION == "-u" ]]; then
			echo "Uploading file \"$FILE\" to host $HOST_PATH"
			scp $FILE $HOST_PATH
			echo ""
			echo "File \"$FILE\" was successfully uploaded to host $HOST_PATH"

		# Print help if some parameter is wrong
		else printHelp
		fi

	else 
		echo ""
		echo "File \"$FILE\" does not exist."
		exit
	fi
fi