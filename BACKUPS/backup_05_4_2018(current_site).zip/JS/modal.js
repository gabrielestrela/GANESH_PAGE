$(document).ready(function(){
    $('.EstatutoModal').modal();
});